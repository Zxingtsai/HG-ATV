# 红果 TV 服务端账号预览更新 0.1.1

先运行原目录 windows/stop.cmd，再将本 ZIP 的内容解压到原安装目录，合并文件夹并覆盖同名源码。
保留原 data、runtime 与 windows/local.settings.json，不需要重新 setup 或更换电视 APK。
启动 windows/start.cmd，再运行 windows/account-login.cmd，用手机红果 App 扫码并确认。

需要服务器已安装 Edge 或 Chrome。详情及真实账号/Windows 尚待验证的范围见 docs/ACCOUNT.zh-CN.md。
这是官网会话登录预览，不包含 App 原生接口或云收藏同步。
